Fruit Slicer 2.1.0 Mod Template
===============================
1. Rename this .zip (or extract it into a subfolder) inside your mods/ folder.
   (modTemplate.zip itself is always ignored by the game.)
2. Edit mod.txt (name= is required; author=, version=, description= are optional).
3. Optional icon.png (64x64 or 128x128 PNG) shows in the Mods menu.
4. Override textures or audio using matching relative paths:
   - Universal: gfx/png/sprites/<name>.png, gfx/board0.png, audio/<track>.ogg
   - 3DS SDMC:  gfx/sprites.t3x, gfx/board0.t3x, audio/<track>.pcm
